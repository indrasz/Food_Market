package com.example.foodmarket.model.dummy

class ProfileMenuModel(tittle:String) {
    var tittle = ""

    init {
        this.tittle = tittle
    }
}